Sources modifiées pour pouvoir utiliser une poignée de gaz.

Clone du projet de [NiklasFauth](https://github.com/NiklasFauth/hoverboard-firmware-hack)
